﻿
Partial Class city
    Inherits System.Web.UI.Page

End Class
